import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput

class MeuApp( App ): 
    def build(self):

        box_principal = BoxLayout(orientation="vertical")
        box_nome = BoxLayout(orientation="horizontal")

        lbl_nome = Label(text="Nome: ")
        self.txt_nome= TextInput()
        box_nome.add_widget(lbl_nome)
        box_nome.add_widget(self.txt_nome)

        box_tel = BoxLayout(orientation="horizontal")
        lbl_tel = Label(text="Tel: ")
        txt_tel = TextInput()
        box_tel.add_widget(lbl_tel)
        box_tel.add_widget(txt_tel)
        
        box_email = BoxLayout(orientation="horizontal")
        lbl_email = Label(text="Email: ")
        txt_email = TextInput()
        box_email.add_widget(lbl_email)
        box_email.add_widget(txt_email)

        box_principal.add_widget(box_email)
        box_principal.add_widget(box_tel)
        box_principal.add_widget(box_nome)

        return box_principal
    
MeuApp().run()